# Medium publishing notes

Status: local draft with screenshots captured from the public WalletGenome website. Nothing has been published or deployed. No Google ranking improvement has been measured.

## Suggested metadata

- Title: How to Analyze an EVM Wallet with WalletGenome
- Subtitle: A visual guide to wallet behavior, capital flows, and approval risk across Ethereum, Base, Arbitrum, and Optimism.
- SEO description: Learn how to analyze an EVM wallet with WalletGenome: review behavior, capital flows, approval history, risk signals, and data coverage across four networks.
- Suggested topics: Blockchain, Ethereum, Cryptocurrency, DeFi, Data Analytics. Select the closest available Medium topics.
- Primary search intent: how to analyze an EVM wallet.
- Related phrases: EVM wallet analytics, multi-chain wallet forensics, token approval checker. These appear where useful; do not add repetitive keyword lists to the article.
- Cover image: 01-wallet-scanner.png.
- Byline: use the actual author and accurately disclose any relationship to WalletGenome. No credentials or firsthand founder story have been invented.

## Keep the original on WalletGenome

Your earlier editorial preference was to keep complete original articles first-party before syndicating them. This draft is a new walkthrough; the existing guide URLs linked inside it are related resources, not an identical original of this draft.

1. Publish the complete article and its images at a dedicated WalletGenome article URL. That URL has not been created by this task.
2. Give the first-party page a self-referencing canonical URL, add discovery links, and include the page in the sitemap.
3. Once that exact article is publicly accessible, use Medium's Import a story feature with its URL. Medium says imported stories automatically reference the original in their canonical URL: https://help.medium.com/hc/en-us/articles/214550207-Importing-a-post-to-Medium
4. Verify the imported draft, images, captions, links, and canonical reference before publishing. If import fails, consult Medium's current manual-import and canonical instructions.
5. Upload the PNGs at their marked positions if the import does not retain them. The local Markdown image paths will not work on Medium. Each image already has descriptive alt text and a caption in article.md.

Do not set this draft's canonical URL to the homepage or a different guide merely because it is related. Canonical URLs should identify the representative version of duplicate or very similar content. Google treats a canonical annotation as a signal and can select another URL: https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls

## Screenshot provenance

- Capture date: September 27, 2026.
- Website: https://www.walletgenome.space/
- Report: https://www.walletgenome.space/?demo=vitalik
- Saved dataset date: August 26, 2026.
- Report history: partial; overall risk grade withheld.
- Screenshots reproduce the product's public demo; they do not independently validate every provider record, identity attribution, classification, or source-list match.
- 05-capital-flow.png is a viewport detail. 05-capital-flow-full.png preserves the complete flow-page capture as a reference.

## What this can improve

The article provides a clear topic, product evidence, descriptive screenshots, and relevant links. These can support discovery and reader understanding. Google recommends original, helpful content grounded in experience and reliable evidence: https://developers.google.com/search/docs/fundamentals/creating-helpful-content

A Medium article does not directly raise a site's Lighthouse SEO or performance score. No ranking gain, indexing, backlink value, or traffic increase is guaranteed.

After publication, track the first-party URL in Search Console: indexing, Google's selected canonical, query impressions, clicks, and average position. Track Medium views and referral visits separately with whatever analytics are actually configured. Compare similar periods and avoid attributing every change to one article.
